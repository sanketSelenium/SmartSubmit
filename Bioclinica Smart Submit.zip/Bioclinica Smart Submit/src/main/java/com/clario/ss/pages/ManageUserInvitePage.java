package com.clario.ss.pages;

public class ManageUserInvitePage {

}
